import singleLogo from "../../common/assets/images/img/circle-logo.png";


export default function TotalStatistic() {
    return (
        <div className="main-totalstatistic py-20">
            <div className="main-container flex flex-col items-center">
                <div>
                    <img src={singleLogo} alt="single-logo" width="100" />
                </div>
                <div className="mt-10">
                    <p className="main-font font-40 main-color text-center main-lineheight py-3 capitalize"> Tow wallets system, double the security measures.
                    </p>
                    <p className="main-font font-40 main-color text-center main-lineheight py-3 capitalize"> One hot wallet with App and one cold wallet.
                    </p>
                </div>
                <div className="mt-10">
                    <p className="main-font font-24 main-color text-center main-lineheight"> Convert your old smartphones into a cold wallet
                    </p>
                </div>
                <div className="mt-10">
                    <p className="font-24 main-font main-color text-center">
                        You can have multiple cold wallets to store your crypto assets.
                    </p>
                </div>
                <div className="mt-10 flex justify-around w-full small-container responsive-col">
                    <div className="home-card hover-transition w-4/5 md:w-2/5">
                        <div className="home-card_icon pb-10">
                            <svg viewBox="0 0 24 24" color="black" width="36px" xmlns="http://www.w3.org/2000/svg" className="sc-bdnxRM jJQZHJ"><path d="M4 13C5.1 13 6 12.1 6 11C6 9.9 5.1 9 4 9C2.9 9 2 9.9 2 11C2 12.1 2.9 13 4 13ZM5.13 14.1C4.76 14.04 4.39 14 4 14C3.01 14 2.07 14.21 1.22 14.58C0.48 14.9 0 15.62 0 16.43V17C0 17.5523 0.447715 18 1 18H4.5V16.39C4.5 15.56 4.73 14.78 5.13 14.1ZM20 13C21.1 13 22 12.1 22 11C22 9.9 21.1 9 20 9C18.9 9 18 9.9 18 11C18 12.1 18.9 13 20 13ZM24 16.43C24 15.62 23.52 14.9 22.78 14.58C21.93 14.21 20.99 14 20 14C19.61 14 19.24 14.04 18.87 14.1C19.27 14.78 19.5 15.56 19.5 16.39V18H23C23.5523 18 24 17.5523 24 17V16.43ZM16.24 13.65C15.07 13.13 13.63 12.75 12 12.75C10.37 12.75 8.93 13.14 7.76 13.65C6.68 14.13 6 15.21 6 16.39V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16.39C18 15.21 17.32 14.13 16.24 13.65ZM8.07 16C8.16 15.77 8.2 15.61 8.98 15.31C9.95 14.93 10.97 14.75 12 14.75C13.03 14.75 14.05 14.93 15.02 15.31C15.79 15.61 15.83 15.77 15.93 16H8.07ZM12 8C12.55 8 13 8.45 13 9C13 9.55 12.55 10 12 10C11.45 10 11 9.55 11 9C11 8.45 11.45 8 12 8ZM12 6C10.34 6 9 7.34 9 9C9 10.66 10.34 12 12 12C13.66 12 15 10.66 15 9C15 7.34 13.66 6 12 6Z"></path></svg>
                        </div>
                        <p className="home-card_title main-font font-38 main-color main-lineheight text-center">
                           App + wallet dowonload
                        </p>
                        <p className="main-font font-28 cursor-pointer main-color-blue main-lineheight pb-10 pt-10 text-center">
                            Find more info
                        </p>
                        {/* <p className=" main-font font-20 main-color">
                            In the last ten days
                        </p> */}
                    </div>
                    <div className="home-card hover-transition w-4/5 md:w-2/5">
                        <div className="home-card_icon pb-10">
                            <svg viewBox="0 0 24 24" color="black" width="36px" xmlns="http://www.w3.org/2000/svg" className="sc-bdnxRM jJQZHJ"><path d="M4 13C5.1 13 6 12.1 6 11C6 9.9 5.1 9 4 9C2.9 9 2 9.9 2 11C2 12.1 2.9 13 4 13ZM5.13 14.1C4.76 14.04 4.39 14 4 14C3.01 14 2.07 14.21 1.22 14.58C0.48 14.9 0 15.62 0 16.43V17C0 17.5523 0.447715 18 1 18H4.5V16.39C4.5 15.56 4.73 14.78 5.13 14.1ZM20 13C21.1 13 22 12.1 22 11C22 9.9 21.1 9 20 9C18.9 9 18 9.9 18 11C18 12.1 18.9 13 20 13ZM24 16.43C24 15.62 23.52 14.9 22.78 14.58C21.93 14.21 20.99 14 20 14C19.61 14 19.24 14.04 18.87 14.1C19.27 14.78 19.5 15.56 19.5 16.39V18H23C23.5523 18 24 17.5523 24 17V16.43ZM16.24 13.65C15.07 13.13 13.63 12.75 12 12.75C10.37 12.75 8.93 13.14 7.76 13.65C6.68 14.13 6 15.21 6 16.39V17C6 17.5523 6.44772 18 7 18H17C17.5523 18 18 17.5523 18 17V16.39C18 15.21 17.32 14.13 16.24 13.65ZM8.07 16C8.16 15.77 8.2 15.61 8.98 15.31C9.95 14.93 10.97 14.75 12 14.75C13.03 14.75 14.05 14.93 15.02 15.31C15.79 15.61 15.83 15.77 15.93 16H8.07ZM12 8C12.55 8 13 8.45 13 9C13 9.55 12.55 10 12 10C11.45 10 11 9.55 11 9C11 8.45 11.45 8 12 8ZM12 6C10.34 6 9 7.34 9 9C9 10.66 10.34 12 12 12C13.66 12 15 10.66 15 9C15 7.34 13.66 6 12 6Z"></path></svg>
                        </div>
                        <p className="home-card_title main-font font-38 main-color main-lineheight text-center">
                            Cold wallet App download 
                        </p>
                        <p className="main-font font-28 main-color-blue cursor-pointer main-lineheight pb-10 pt-10 text-center">
                            Find more info
                        </p>
                        {/* <p className=" main-font font-20 main-color">
                            In the last ten days
                        </p> */}
                    </div>
                </div>
            </div>
        </div >
    );
}
