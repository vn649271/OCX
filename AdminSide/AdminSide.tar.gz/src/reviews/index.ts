import ReviewIcon from '@material-ui/icons/Comment';
import ReviewList from './ReviewList';

export default {
    icon: ReviewIcon,
    list: ReviewList,
};
