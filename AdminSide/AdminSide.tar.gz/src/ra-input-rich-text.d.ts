declare module 'ra-input-rich-text';
