declare module 'json-graphql-server';
